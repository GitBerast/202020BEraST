package com.example.gozkurali

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var btn: Button
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
            setBackgroundColor(Color.parseColor("#F4F7F6"))
        }
        root.addView(TextView(this).apply {
            text = "👁️ 20-20-20 Göz Kuralı"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#14302B"))
        })
        info = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 48)
            setTextColor(Color.parseColor("#5B7570"))
        }
        root.addView(info)
        btn = Button(this).apply { setOnClickListener { toggle() } }
        root.addView(btn)
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun toggle() {
        val i = Intent(this, EyeService::class.java)
        if (EyeService.running) {
            i.action = EyeService.ACTION_STOP
            startService(i)
            EyeService.running = false
        } else {
            startForegroundService(i)
            EyeService.running = true
        }
        refresh()
    }

    private fun refresh() {
        btn.text = if (EyeService.running) "Durdur" else "Başlat"
        info.text = if (EyeService.running)
            "Çalışıyor. Her 20 dakikada bir 20 saniyelik mola bildirimi gelecek. Uygulamayı kapatabilirsin."
        else
            "Başlat'a bas. Her 20 dakikada 20 saniye, 6 metre uzağa bakmanı hatırlatırım."
    }
}
