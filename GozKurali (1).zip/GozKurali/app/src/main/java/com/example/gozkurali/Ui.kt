package com.example.gozkurali

import android.content.Context
import android.graphics.*
import android.view.View

class BackgroundView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = minOf(w, h)
        p.shader = LinearGradient(0f, 0f, w, h,
            Color.parseColor("#07141C"), Color.parseColor("#102A33"), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p)
        blob(canvas, w * .22f, h * .25f, m * .75f, Color.parseColor("#2FC4AE"))
        blob(canvas, w * .80f, h * .30f, m * .65f, Color.parseColor("#7A5CFF"))
        blob(canvas, w * .60f, h * .90f, m * .80f, Color.parseColor("#F0A064"))
    }
    private fun blob(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        val clear = color and 0x00FFFFFF
        p.shader = RadialGradient(x, y, r,
            intArrayOf(clear or (0x99 shl 24), clear), null, Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p)
    }
}

class RingView(c: Context) : View(c) {
    var progress = 1f
    var accent = Color.parseColor("#2FC4AE")
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(45, 255, 255, 255)
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    override fun onDraw(canvas: Canvas) {
        val s = 10f * resources.displayMetrics.density
        track.strokeWidth = s
        arc.strokeWidth = s
        arc.color = accent
        val r = RectF(s, s, width - s, height - s)
        canvas.drawArc(r, 0f, 360f, false, track)
        canvas.drawArc(r, -90f, 360f * progress, false, arc)
    }
}
