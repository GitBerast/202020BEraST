package com.example.gozkurali

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.*

class EyeService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile var endAt = 0L
        @Volatile var totalMs = 20 * 60 * 1000L
        @Volatile var breakActive = false
        const val ACTION_STOP = "stop"
        const val WORK_MS = 20 * 60 * 1000L
        const val BREAK_MS = 20 * 1000L
        const val CH_ONGOING = "ongoing"
        const val CH_ALERT = "alert"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wl: PowerManager.WakeLock? = null
    private var inBreak = false
    private val tick = Runnable { if (inBreak) endBreak() else startBreak() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_ONGOING, "Sayaç", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Göz molası uyarıları", NotificationManager.IMPORTANCE_HIGH).apply {
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400)
            })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        if (wl == null) {
            wl = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "gozkurali:timer").apply { acquire() }
        }
        handler.removeCallbacks(tick)
        startWork()
        return START_STICKY
    }

    private fun begin(ms: Long, isBreak: Boolean) {
        inBreak = isBreak
        breakActive = isBreak
        totalMs = ms
        endAt = System.currentTimeMillis() + ms
        handler.postDelayed(tick, ms)
    }

    private fun startWork() {
        begin(WORK_MS, false)
        showOngoing("Sonraki mola", WORK_MS)
    }

    private fun startBreak() {
        begin(BREAK_MS, true)
        alert("Göz molası 👀", "20 saniye boyunca 6 metre uzağa bak.")
        showOngoing("Şimdi uzağa bak", BREAK_MS)
    }

    private fun endBreak() {
        alert("Mola bitti ✅", "Çalışmaya devam edebilirsin. Sonraki mola 20 dakika sonra.")
        startWork()
    }

    private fun openApp() = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    private fun showOngoing(title: String, ms: Long) {
        val stop = PendingIntent.getService(
            this, 1, Intent(this, EyeService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH_ONGOING)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle(title)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setWhen(System.currentTimeMillis() + ms)
            .setContentIntent(openApp())
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                "Durdur", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else
            startForeground(1, n)
    }

    // Zaman aşımı yok: kullanıcı dokunana veya kaydırana kadar bildirim kalır.
    private fun alert(title: String, text: String) {
        val n = Notification.Builder(this, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(Notification.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(openApp())
            .build()
        getSystemService(NotificationManager::class.java).notify(2, n)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        wl?.let { if (it.isHeld) it.release() }
        wl = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
