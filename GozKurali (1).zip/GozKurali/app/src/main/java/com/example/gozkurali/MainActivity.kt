package com.example.gozkurali

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*

class MainActivity : Activity() {
    private lateinit var btn: Button
    private lateinit var time: TextView
    private lateinit var label: TextView
    private lateinit var ring: RingView
    private var shown: Boolean? = null
    private val h = Handler(Looper.getMainLooper())
    private val ui = object : Runnable {
        override fun run() { render(); h.postDelayed(this, 250) }
    }
    private val teal = Color.parseColor("#2FC4AE")
    private val orange = Color.parseColor("#F0A064")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun glass(radius: Int, top: String, bottom: String, stroke: String) =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor(top), Color.parseColor(bottom))).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.parseColor(stroke))
        }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#07141C")
        window.navigationBarColor = Color.parseColor("#102A33")

        val root = FrameLayout(this)
        root.addView(BackgroundView(this), FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val holder = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        val cw = minOf(dp(360), resources.displayMetrics.widthPixels - dp(32))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(30), dp(28), dp(28))
            background = glass(36, "#33FFFFFF", "#14FFFFFF", "#55FFFFFF")
        }
        holder.addView(card, LinearLayout.LayoutParams(cw, WRAP_CONTENT))
        scroll.addView(holder, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        card.addView(text("👁️ 20-20-20 Göz Kuralı", 22f, Color.WHITE, true))
        card.addView(text("Her 20 dakikada 20 saniye, 6 metre uzağa bak.", 14f,
            Color.parseColor("#B3FFFFFF")).apply { setPadding(0, dp(6), 0, dp(22)) })

        ring = RingView(this)
        time = TextView(this).apply {
            textSize = 46f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        label = text("", 14f, Color.parseColor("#B3FFFFFF"))
        val center = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(time)
            addView(label)
        }
        val ringBox = FrameLayout(this)
        ringBox.addView(ring, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        ringBox.addView(center, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        card.addView(ringBox, LinearLayout.LayoutParams(dp(210), dp(210)))

        btn = Button(this).apply {
            stateListAnimator = null
            isAllCaps = false
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setOnClickListener { toggle() }
        }
        card.addView(btn, LinearLayout.LayoutParams(MATCH_PARENT, dp(56)).apply { topMargin = dp(26) })
        card.addView(text("Uyarı, bildirime dokunana kadar ekranda kalır.", 12f,
            Color.parseColor("#80FFFFFF")).apply { setPadding(0, dp(14), 0, 0) })

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() { super.onResume(); h.post(ui) }
    override fun onPause() { super.onPause(); h.removeCallbacks(ui) }

    private fun toggle() {
        val i = Intent(this, EyeService::class.java)
        if (EyeService.running) {
            i.action = EyeService.ACTION_STOP
            startService(i)
            EyeService.running = false
        } else {
            startForegroundService(i)
            EyeService.running = true
            EyeService.endAt = System.currentTimeMillis() + EyeService.WORK_MS
            EyeService.totalMs = EyeService.WORK_MS
            EyeService.breakActive = false
        }
        render()
    }

    private fun render() {
        val run = EyeService.running
        if (shown != run) {
            shown = run
            btn.text = if (run) "Durdur" else "Başlat"
            btn.background = if (run) glass(28, "#552FC4AE", "#332FC4AE", "#882FC4AE")
            else glass(28, "#4DFFFFFF", "#26FFFFFF", "#66FFFFFF")
        }
        if (run) {
            val left = maxOf(0L, EyeService.endAt - System.currentTimeMillis())
            val s = (left + 999) / 1000
            time.text = "%02d:%02d".format(s / 60, s % 60)
            ring.progress = (left.toFloat() / EyeService.totalMs).coerceIn(0f, 1f)
            ring.accent = if (EyeService.breakActive) orange else teal
            label.text = if (EyeService.breakActive) "Şimdi uzağa bak" else "Sonraki mola"
        } else {
            time.text = "20:00"
            ring.progress = 1f
            ring.accent = teal
            label.text = "Hazır"
        }
        ring.invalidate()
    }
}
