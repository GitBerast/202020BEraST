package com.example.gozkurali

import android.content.Context
import android.graphics.*
import android.view.View

/** Renkli ışık lekeleri olan koyu zemin (cam efektinin arkası). */
class BgView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.shader = LinearGradient(
            0f, 0f, w, h,
            intArrayOf(Color.rgb(11, 18, 32), Color.rgb(16, 38, 58), Color.rgb(27, 24, 64)),
            null, Shader.TileMode.CLAMP
        )
        cv.drawRect(0f, 0f, w, h, p)
        val m = minOf(w, h)
        blob(cv, w * 0.15f, h * 0.20f, m * 0.8f, Color.rgb(31, 200, 176))
        blob(cv, w * 0.88f, h * 0.35f, m * 0.8f, Color.rgb(123, 92, 255))
        blob(cv, w * 0.50f, h * 0.98f, m * 0.8f, Color.rgb(255, 138, 76))
    }

    private fun blob(cv: Canvas, x: Float, y: Float, r: Float, col: Int) {
        val a = Color.argb(150, Color.red(col), Color.green(col), Color.blue(col))
        val z = Color.argb(0, Color.red(col), Color.green(col), Color.blue(col))
        p.shader = RadialGradient(x, y, r, a, z, Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, r, p)
    }
}

/** Parlayan geri sayım halkası. */
class RingView(c: Context) : View(c) {
    private var progress = 1f
    private var accent = Color.WHITE
    private var big = ""
    private var small = ""

    private fun stroke() = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val track = stroke().apply { color = Color.argb(45, 255, 255, 255) }
    private val arc = stroke()
    private val glow = stroke()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(22, 255, 255, 255) }
    private val tBig = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    }
    private val tSmall = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(190, 255, 255, 255)
        textAlign = Paint.Align.CENTER
    }
    private val box = RectF()

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val sw = minOf(w, h) * 0.055f
        glow.maskFilter = BlurMaskFilter(sw * 1.2f, BlurMaskFilter.Blur.NORMAL)
    }

    fun set(p: Float, color: Int, b: String, s: String) {
        progress = p.coerceIn(0f, 1f)
        accent = color
        big = b
        small = s
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat()
        val sw = s * 0.055f
        val cx = width / 2f
        val cy = height / 2f
        val r = s / 2f - sw * 1.5f
        box.set(cx - r, cy - r, cx + r, cy + r)
        track.strokeWidth = sw
        arc.strokeWidth = sw
        glow.strokeWidth = sw * 1.6f
        arc.color = accent
        glow.color = Color.argb(170, Color.red(accent), Color.green(accent), Color.blue(accent))

        cv.drawCircle(cx, cy, r - sw, fill)
        cv.drawArc(box, 0f, 360f, false, track)
        val sweep = 360f * progress
        if (sweep > 0.5f) {
            cv.drawArc(box, -90f, sweep, false, glow)
            cv.drawArc(box, -90f, sweep, false, arc)
        }
        tBig.textSize = s * 0.2f
        tSmall.textSize = s * 0.068f
        cv.drawText(big, cx, cy + s * 0.04f, tBig)
        cv.drawText(small, cx, cy + s * 0.17f, tSmall)
    }
}
